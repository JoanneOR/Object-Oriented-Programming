CREATE TABLE mytable (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT
);